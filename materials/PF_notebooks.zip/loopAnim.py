import re
import ipywidgets as widgets
from IPython.display import clear_output, display

class LoadedButton(widgets.Button):
    def __init__(self, str_=None, name=None, day='', print_=False, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.output = widgets.Output()
        self.str_ = str_
        self.name = name
        self.day = day
        self.print_ = print_
        self.init_sequences()
        
    def update_str_(self):
        self.str_ = self.str_.replace('===>', '    ')
        self.str_ = self.str_.replace(str(self.pos)+'     ', str(self.pos)+' ===>')
        
        if self.print_ and self.pos == 6:
            print_line = '8 ' + self.name + ' works ' + self.day
            self.str_ = re.sub(r'[8][ \w]*', print_line, self.str_)
        print(self.str_.format(name=self.name, day=self.day))

    def init_sequences(self):
        names = ['sarah', 'john', 'abigail', 'martin']
        days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] * 4
        positions = ([4] + [5, 6] * 5) * 4
        self.names = iter(names)
        self.days = iter(days)
        self.positions = iter(positions)
        self.pos = next(self.positions)
    
    
def on_botton_clicked(button):
    button.description = 'Next step'
    if button.pos == 4:
        button.name = next(button.names)
    elif button.pos == 5:
        button.day = next(button.days)
    elif button.pos == 6:
        button.print_ = True
    with button.output:
        clear_output()
        button.update_str_()
    try:
        button.pos = next(button.positions)
    except StopIteration:
        button.description = 'RESTART for loop'
        button.init_sequences()


def animated_for_loop():
    output = widgets.Output()
    button = LoadedButton(description='Next step')
    button.str_ = """
    1      names = ['sarah', 'john', 'abigail', 'martin']
    2      working_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    3
    4 ===> for name in names:                      name: {name}
    5          for day in working_days:            day:  {day}
    6             print(name, 'works', day)
    7
    8"""

    display(button, button.output)

    with button.output:
        clear_output()
        button.name = next(button.names)
        button.update_str_()
        button.pos = next(button.positions)
        
    button.on_click(on_botton_clicked)
